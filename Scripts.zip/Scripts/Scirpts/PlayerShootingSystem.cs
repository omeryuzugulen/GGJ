using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;

public class PlayerShootingSystem : MonoBehaviour
{
    [SerializeField] GameObject BulletPrefab;
    [SerializeField] Transform ShootPosition;

    public int ShootCount;

    public int BulletCount;

    public float TimeScale;

    Animator anim;

    [SerializeField] float Timer;
    public float Cooldown;

    public bool TutorialShootLock;

    [SerializeField] GameObject Limage1;
    [SerializeField] GameObject Limage2;

    [SerializeField] AudioClip ShootSound;
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        if (Input.GetMouseButtonUp(0) && ShootCount > 0 && !TutorialShootLock)
        {
        Shoot();
        }

        if (ShootCount <= 0 && !TutorialShootLock)
        {
            if (Cooldown <= 0)
            {
                ChangeShootCount(1);
            }
            else
            {
                Cooldown -= Time.deltaTime;
            }
        }
        else
        {
            Cooldown = Timer;
        }
    }
    void Shoot()
    {
        if(Limage2 != null)
        {
            Limage1.SetActive(false);
            Limage2.SetActive(true);
            Destroy(Limage2, 0.5f);
        }

        AudioSource.PlayClipAtPoint(ShootSound,transform.position);
        GameObject.Find("Main Camera").GetComponent<Animator>().SetTrigger("Shake");
        ShootCount--;
        anim.SetTrigger("PlayerShotTrigger");
        Instantiate<GameObject>(BulletPrefab,ShootPosition.position,transform.rotation);
        Debug.Log("S�kt�");
        AddBulletCount(1);
    }

    public void ChangeShootCount(int Count)
    {
        ShootCount = Count;
    }


    public void EnemyHited()
    {
        ChangeShootCount(1);
        GetComponent<PlayerController>().AddJumpCount(1);
    }

    public void AddBulletCount(int Count)
    {
        BulletCount += Count;
    }
    public void AddShootCount(int Count)
    {
        ShootCount += Count;
    }
    public void StartShoot()
    {
        TutorialShootLock = false;
        Limage1.SetActive(true);
    }
}
