using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public Transform target;
    public Vector3 LastTarget;
    Vector3 LastPos;

    public float speed = 6f;
    public float Attackspeed = 6f;
    private float minDistance = 1f;
    private float range;

    public bool Attack;
    public bool Attack2;
    public float AttackWaitInt;
    public float MoveAgainInt;

    Vector2 lookdir;
    Vector2 playerpos;
    Rigidbody2D rb;

    [SerializeField] GameObject Particle;

    public bool stopper;

    [SerializeField] GameObject Trail;

    PlayerShootingSystem playerShootingSystem;
            
    public enum State {
        gotoplayer,
        gotoplayghost
    }
    public State CurnState;
    public float gotoplayghoststartentertime;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        playerShootingSystem = FindObjectOfType<PlayerShootingSystem>();
    }

    void Update()
    {
        target = GameObject.Find("Player").transform;
     
        switch (CurnState)
        {
            case State.gotoplayer:
                Trail.SetActive(false);
                transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
                
                break;
            case State.gotoplayghost:
                this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
                if (Time.time - gotoplayghoststartentertime > 1)
                {
                    transform.position = Vector2.MoveTowards(transform.position, LastPos, Attackspeed * Time.deltaTime);
                    Trail.SetActive(true);
                    

                    if (transform.position == LastPos)
                    {
                        if (Time.time - gotoplayghoststartentertime > 2)
                        {
                            CurnState = State.gotoplayer;
                        }
                    } 
                }
                break;
            default:
                break;
        }
    }
    private void FixedUpdate()
    {
        if (!Attack2)
        {
            lookdir = playerpos - rb.position;
            float angle = Mathf.Atan2(lookdir.y, lookdir.x) * Mathf.Rad2Deg;
            rb.rotation = angle;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.TryGetComponent<PlayerCricle>(out var playerCricle))
        {
            CurnState = State.gotoplayghost;
            gotoplayghoststartentertime = Time.time;
            LastPos = target.transform.position;
        }
        if(collision.gameObject.TryGetComponent<BulletScript>(out var bulletScript))
        {
            Instantiate<GameObject>(Particle, transform.position, Quaternion.identity);
            GameObject.Find("Main Camera").GetComponent<Animator>().SetTrigger("ShakeBigger");
            Destroy(gameObject);
        }
        if (collision.gameObject.TryGetComponent<Enemy>(out var enemy))
        {
            this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
        }
    }

    private void OnDestroy()
    {
        if(FindObjectOfType<EnemySpawn>() != null)
        {
            FindObjectOfType<EnemySpawn>().ChangeEnemyCount();
        }
        
        if(playerShootingSystem != null)
        {
            if (gameObject.tag == "Orange")
            {
                playerShootingSystem.gameObject.GetComponent<PlayerController>().ChangeJumpCount(1);
                playerShootingSystem.ChangeShootCount(2);
            }
            else if (gameObject.tag == "Blue")
            {
                playerShootingSystem.ChangeShootCount(1);
                playerShootingSystem.gameObject.GetComponent<PlayerController>().ChangeJumpCount(2);
            }
            else
            {
                playerShootingSystem.gameObject.GetComponent<PlayerController>().ChangeJumpCount(1);
                playerShootingSystem.ChangeShootCount(1);
            }
        }
        Debug.Log("Oldum");
    }

}
