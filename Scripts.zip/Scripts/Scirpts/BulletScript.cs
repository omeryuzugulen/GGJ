using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using UnityEngine.SceneManagement;

public class BulletScript : MonoBehaviour
{
    PlayerShootingSystem playerShootingSystem;
    Rigidbody2D rb;
    [SerializeField] float Speed;

    [SerializeField] AudioClip Explosion;
    [SerializeField] AudioClip BigExplosion;
    // Start is called before the first frame update
    void Start()
    {
        playerShootingSystem = FindObjectOfType<PlayerShootingSystem>();
        rb = GetComponent<Rigidbody2D>();
        rb.velocity = transform.right * Speed;
        Destroy(gameObject, 5);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Hit()
    {
        playerShootingSystem.AddBulletCount(-1);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        //if (collision.gameObject.tag == "Enemy")
        //{
        //    Destroy(collision.gameObject);
        //    playerShootingSystem.EnemyHited();
        //    GameObject.Find("Player").GetComponent<PlayerShootingSystemOY>().Translater();
        //    GameObject.Find("Player").GetComponent<PlayerControllerOY>().jump = false;
            
        //    Debug.Log("Vyurdur");
        //    Destroy(gameObject);
        //}

        if(collision.gameObject.tag == "Enemy")
        {
            //Destroy(enemy.gameObject);
            //playerShootingSystem.EnemyHited();

            //GameObject.Find("player").GetComponent<playershootingsystemoy>().translater();
            //GameObject.Find("player").getcomponent<playercontrolleroy>().jump = false;


            Debug.Log("vyurdur");
            AudioSource.PlayClipAtPoint(Explosion, transform.position);
            Destroy(gameObject);
        }
        if (collision.gameObject.tag == "Orange")
        {
            //playerShootingSystem.EnemyHited();
            AudioSource.PlayClipAtPoint(Explosion, transform.position);
            Destroy(gameObject);
        }
        if (collision.gameObject.tag == "Blue")
        {
            //playerShootingSystem.EnemyHited();
            AudioSource.PlayClipAtPoint(Explosion, transform.position);
            Destroy(gameObject);
        }
        if (collision.gameObject.tag == "Start")
        {
            //playerShootingSystem.EnemyHited();

            SceneManager.LoadScene(2);
        }
    }
}
