using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Level", menuName = "Level/LevelObject")]
public class Level : ScriptableObject
{
    //Wave nereden ka� tane geldi�i de�i�ebilir
    // Start is called before the first frame update

    public Wave[] waves;
    public GameObject LevelPrefab;
}
