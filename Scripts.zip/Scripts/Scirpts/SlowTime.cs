using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlowTime : MonoBehaviour
{
    [SerializeField] float SlowTimer;
    [SerializeField] float Timer;
    [SerializeField] float TimeScale;
    [SerializeField] bool Slow;

    PlayerController playerController;
    PlayerShootingSystem playerShootingSystem;
    // Start is called before the first frame update
    void Start()
    {
        playerController = GetComponent<PlayerController>();
        playerShootingSystem = GetComponent<PlayerShootingSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        if (((Input.GetMouseButton(0) && playerShootingSystem.ShootCount > 0) || (Input.GetMouseButton(1) && playerController.JumpCount > 0)) && Timer>0)
        {
            Slow = true;
            Timer -= Time.deltaTime;
            Time.timeScale = TimeScale;
        }
        else
        {
            Slow = false;
            if (Timer<SlowTimer)
            {
                Timer += Time.deltaTime;
            }             
            Time.timeScale = 1;
        }
    }
}
