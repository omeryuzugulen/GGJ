using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class UIScript : MonoBehaviour
{
    [SerializeField] GameObject R1;
    [SerializeField] GameObject R2;
    [SerializeField] GameObject L1;
    [SerializeField] GameObject L2;
    GameObject Player;

    [SerializeField] TextMeshProUGUI R1Text;
    [SerializeField] TextMeshProUGUI L1Text;
    // Start is called before the first frame update
    void Start()
    {
        Player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Player.transform.position;

        R1Text.text = ((int)FindObjectOfType<PlayerController>().Cooldown+1).ToString();
        L1Text.text = ((int)FindObjectOfType<PlayerShootingSystem>().Cooldown+1).ToString();

        if (FindObjectOfType<PlayerController>().JumpCount > 1)
        {
            R2.SetActive(true);
            R1.SetActive(true);
        }
        else if(FindObjectOfType<PlayerController>().JumpCount == 1)
        {
            R1.SetActive(true);
            R2.SetActive(false);
        }
        else
        {
            R1.SetActive(false);
            R2.SetActive(false);
        }

        if (FindObjectOfType<PlayerShootingSystem>().ShootCount > 1)
        {
            L2.SetActive(true);
            L2.SetActive(true);
        }
        else if (FindObjectOfType<PlayerShootingSystem>().ShootCount == 1)
        {
            L1.SetActive(true);
            L2.SetActive(false);
        }
        else
        {
            L1.SetActive(false);
            L2.SetActive(false);
        }
    }
}
