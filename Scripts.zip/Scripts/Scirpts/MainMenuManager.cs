using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MainMenuManager : MonoBehaviour
{
    [SerializeField] GameObject Fimage1;
    [SerializeField] GameObject Fimage2;


    [SerializeField] GameObject volume;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if(FindObjectOfType<PlayerController>().TutorialJumpLock == false && Input.GetMouseButtonUp(1))
        {
            //GameObject.Find("Player").GetComponent<Animator>().SetTrigger("Rotate");
            GameObject.Find("Player").GetComponent<Animator>().SetTrigger("Dash");
            GetComponent<Animator>().SetTrigger("Con");
            Fimage1.SetActive(false);
            Fimage2.SetActive(true);
            Destroy(Fimage2, 0.5f);
            volume.SetActive(false);
        }
        if (Input.GetMouseButtonUp(1) && FindObjectOfType<PlayerController>().TutorialJumpLock == false)
        {
            FindObjectOfType<PlayerController>().TutorialJumpLock = true;
        }
    }

    public void StartDash()
    {
        FindObjectOfType<PlayerController>().TutorialJumpLock = false;
        Fimage1.SetActive(true);
        volume.SetActive(true);
    }

    public void StartRotate()
    {
        GameObject.Find("Player").GetComponent<Animator>().SetTrigger("Rotate");
    }
}
