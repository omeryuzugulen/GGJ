using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletScriptEnemy : MonoBehaviour
{
    PlayerShootingSystem playerShootingSystem;
    Rigidbody2D rb;
    [SerializeField] float Speed;
    // Start is called before the first frame update
    void Start()
    {
        //playerShootingSystem = FindObjectOfType<PlayerShootingSystem>();
        rb = GetComponent<Rigidbody2D>();
        rb.velocity = transform.right * Speed;
        Destroy(gameObject, 5);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void Hit()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.tag == "Player")
        {
            Destroy(collision.gameObject);
           
        }
    }
}
