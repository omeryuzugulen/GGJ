using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using DG.Tweening;

public class PlayerControllerOY : MonoBehaviour
{
    Vector2 MousePos;
    Rigidbody2D rb;
    [SerializeField] float MovementSpeed;
    [SerializeField] float RotationtSpeed;
    [SerializeField] float MovementRange;
    [SerializeField] Transform JumpPosition;
    Vector2 lookdir;

    public int JumpCount;

    public bool jump;

    Animator anim;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        MousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        JumpPosition.localPosition = new Vector2(MovementRange,0);

        if (Input.GetMouseButtonUp(1))
        {
            if (!jump)
            {
                jump = true;
                anim.SetTrigger("PlayerEscapeTrigger");
                transform.DOMove(JumpPosition.position, MovementSpeed);
                StartCoroutine(Waiting());
            }
            
        }
    }
    IEnumerator Waiting()
    {
        yield return new WaitForSeconds(3);
        jump = false;

    }
    private void FixedUpdate()
    {
        lookdir = MousePos - rb.position;

        float angle = Mathf.Atan2(lookdir.y, lookdir.x) * Mathf.Rad2Deg;
        transform.DORotate(new Vector3(0,0, angle), RotationtSpeed, RotateMode.Fast).SetEase(Ease.OutSine);
    }

    public void ChangeJumpCount(int Count)
    {
        JumpCount = Count;
    }
}

//
