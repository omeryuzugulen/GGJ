using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Wave",menuName = "Level/Wave")]
public class Wave : ScriptableObject
{
    [Header("Up")]
    public GameObject[] Spawner1Enemies;
    [Header("Left")]
    public GameObject[] Spawner2Enemies;
    [Header("Down")]
    public GameObject[] Spawner3Enemies;
    [Header("Right")]
    public GameObject[] Spawner4Enemies;
}
