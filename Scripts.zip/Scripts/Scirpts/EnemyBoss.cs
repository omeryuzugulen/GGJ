using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBoss : MonoBehaviour
{
    public Transform target;
    public Vector3 LastTarget;
    Vector3 LastPos;

    public float speed = 6f;
    public float Attackspeed = 6f;
    private float minDistance = 1f;
    private float range;

    public bool Attack;
    public bool Attack2;
    public float AttackWaitInt;
    public float MoveAgainInt;

    Vector2 lookdir;
    Vector2 playerpos;
    Rigidbody2D rb;

    [SerializeField] GameObject Particle;

    public bool stopper;

    [SerializeField] GameObject Trail;

    public enum State {
        gotoplayer,
        gotoplayghost
    }
    public State CurnState;
    public float gotoplayghoststartentertime;

    public int life = 3;

    Animator anim;
    public GameObject fullhp;
    public GameObject halfhp;
    public GameObject nohp;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        target = GameObject.Find("Player").transform;
     
        switch (CurnState)
        {
            case State.gotoplayer:
                Trail.SetActive(false);
                transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
                
                break;
            case State.gotoplayghost:
                this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
                if (Time.time - gotoplayghoststartentertime > 1)
                {
                    transform.position = Vector2.MoveTowards(transform.position, LastPos, Attackspeed * Time.deltaTime);
                    Trail.SetActive(true);
                    

                    if (transform.position == LastPos)
                    {
                        if (Time.time - gotoplayghoststartentertime > 2)
                        {
                            CurnState = State.gotoplayer;
                        }
                    } 
                }
                break;
            default:
                break;
        }
        
    }
    private void FixedUpdate()
    {
        if (!Attack2)
        {
            lookdir = playerpos - rb.position;
            float angle = Mathf.Atan2(lookdir.y, lookdir.x) * Mathf.Rad2Deg;
            rb.rotation = angle;
        }
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
      
        if(collision.gameObject.TryGetComponent<BulletScript>(out var bulletScript))
        {
        
            Instantiate<GameObject>(Particle, transform.position, Quaternion.identity);
            life--;
            if(life == 2)
            {
                anim.SetTrigger("GetHit1Trigger");
                StartCoroutine(bir());
                
            }
            if (life == 1)
            {
                anim.SetTrigger("GetHit2Trigger");
                StartCoroutine(iki());
                
            }
            

            GameObject.Find("Main Camera").GetComponent<Animator>().SetTrigger("ShakeBigger");
            if(life == 0)
            {
                Destroy(gameObject);
            }
        }
        if(collision.gameObject.tag == "Player")
        {
            GameObject.Find("Player").GetComponent<PlayerHealthSystem>().Death();
        }
     
    }
    IEnumerator bir()
    {
        yield return new WaitForSeconds(0.3f);
        fullhp.SetActive(false);
        halfhp.SetActive(true);
    }
    IEnumerator iki()
    {
        yield return new WaitForSeconds(0.3f);
        halfhp.SetActive(false);
        nohp.SetActive(true);
    }

    private void OnDestroy()
    {
        FindObjectOfType<EnemySpawn>().ChangeEnemyCount();
        Debug.Log("Oldum");
    }

}
