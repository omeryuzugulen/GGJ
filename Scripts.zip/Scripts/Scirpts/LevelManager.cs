using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelManager : MonoBehaviour
{
    [SerializeField] GameObject[] Levels;
    GameObject CurrentLevel;
    // Start is called before the first frame update
    void Start()
    {
        NextLevel();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void NextLevel()
    {
        if(CurrentLevel != null)
        {
            Destroy(CurrentLevel);
        }
        int index = Random.Range(0, Levels.Length);
        if(Levels[index] != null)
        {
            GameObject NewLevel = Instantiate<GameObject>(Levels[index], Vector3.zero, Quaternion.identity);
            CurrentLevel = NewLevel;
        }
    }
}
