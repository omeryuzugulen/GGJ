using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Audio;
using DG.Tweening;

public class PlayerController : MonoBehaviour
{
    Vector2 MousePos;
    Rigidbody2D rb;
    [SerializeField] float MovementSpeed;
    [SerializeField] float RotationtSpeed;
    [SerializeField] float MovementRange;
    [SerializeField] Transform JumpPosition;
    Vector2 lookdir;

    public int JumpCount;

    Animator anim;

    [SerializeField] float Timer;

    [SerializeField] GameObject R1UI;
    [SerializeField] GameObject R2UI;
    public float Cooldown;

    public bool TutorialJumpLock;
    public bool Tutorial;

    [SerializeField] AudioClip DashSound;
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        //if (JumpCount > 1)
        //{
        //    R1UI.SetActive(true);
        //}
        //else if(JumpCount == 1)
        //{
        //    R1UI.SetActive(true);
        //}
        //else
        //{
        //    R1UI.SetActive(false);
        //}

        MousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        JumpPosition.localPosition = new Vector2(MovementRange,0);

        if (Input.GetMouseButtonUp(1) && JumpCount>0 && !TutorialJumpLock)
        {
            JumpCount--;
            anim.SetTrigger("PlayerEscapeTrigger");
            transform.DOMove(JumpPosition.position,MovementSpeed);
            AudioSource.PlayClipAtPoint(DashSound,transform.position);
        }


        if (JumpCount <= 0 && !TutorialJumpLock)
        {
            if(Cooldown <= 0)
            {
                ChangeJumpCount(1);
            }
            else
            {
                Cooldown -= Time.deltaTime;
            }           
        }
        else
        {
            Cooldown = Timer;
        }
    }
    private void FixedUpdate()
    {
        //if (!Tutorial)
        //{
            lookdir = MousePos - rb.position;
       // Debug.Log(lookdir);
            float angle = Mathf.Atan2(lookdir.y, lookdir.x) * Mathf.Rad2Deg;
        transform.DORotate(new Vector3(0, 0, angle), RotationtSpeed, RotateMode.Fast).SetEase(Ease.OutSine);
        //rb.rotation = angle;
        //}        
    }

    public void ChangeJumpCount(int Count)
    {
        JumpCount = Count;
    }

    public void AddJumpCount(int Count)
    {
        JumpCount += Count;
    }
}

