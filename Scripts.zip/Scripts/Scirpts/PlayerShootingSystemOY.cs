using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerShootingSystemOY : MonoBehaviour
{
    [SerializeField] GameObject BulletPrefab;
    [SerializeField] Transform ShootPosition;

    public int ShootCount;

    public int BulletCount;

    public float TimeScale;

    public bool shut;

    Animator anim;
    void Start()
    {
        anim = GetComponent<Animator>();
    }

    void Update()
    {
        if (Input.GetMouseButtonUp(0))
        {
            if (!shut)
            {
                Shoot();
                shut = true;
                StartCoroutine(Waiting());
                
            }
            
          //  StartCoroutine(Waiting());
        }
    }
    void Shoot()
    {
        if (!shut)
        {
            anim.SetTrigger("PlayerShotTrigger");
            Instantiate<GameObject>(BulletPrefab, ShootPosition.position, transform.rotation);
            AddBulletCount(1);
        }
        
        
    }

    public void ChangeShootCount(int Count)
    {
        ShootCount = Count;
    }
    IEnumerator Waiting()
    {
        if (shut)
        {
            yield return new WaitForSeconds(3);
            shut = false;
            yield return null;
        }
    }
    public void Translater()
    {
        StartCoroutine(ClickDefence());
    }
    public IEnumerator ClickDefence()
    {
        if (shut)
        {
            yield return new WaitForSeconds(0.5f);
            shut = false;
            yield return null;
        }
        
    }

    public void EnemyHited()
    {
        ChangeShootCount(1);
        GetComponent<PlayerController>().AddJumpCount(1);
    }

    public void AddBulletCount(int Count)
    {
        BulletCount += Count;
    }
}
