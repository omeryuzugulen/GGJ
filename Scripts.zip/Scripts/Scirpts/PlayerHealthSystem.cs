using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerHealthSystem : MonoBehaviour
{
    PlayerController playerController;
    PlayerShootingSystem playerShootingSystem;

    [Header("X Range")]
    public float xMin;
    public float xMax;

    // the range of y
    [Header("Y Range")]
    public float yMin;
    public float yMax;
    // Start is called before the first frame update
    void Start()
    {
        playerController = GetComponent<PlayerController>();
        playerShootingSystem = GetComponent<PlayerShootingSystem>();
    }

    // Update is called once per frame
    void Update()
    {
        //if(playerController.JumpCount <= 0 && playerShootingSystem.ShootCount <= 0 && playerShootingSystem.BulletCount<=0)
        //{
        //    Death();
        //}

        //if(transform.position.x > xMax || transform.position.x < xMin || transform.position.y > yMax || transform.position.y < yMin)
        //{
        //    Death();
        //}
    }

    public void Death()
    {
        SceneManager.LoadScene(1);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 6)
        {
            Debug.Log("�ld�rd�r" + collision.gameObject.name);
            Death();
        }
    }
}
