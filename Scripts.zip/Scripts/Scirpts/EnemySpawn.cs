using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EnemySpawn : MonoBehaviour
{
    public GameObject[] theGoodies;
    GameObject goods;

    //Time it takes to spawn theGoodies
    [Space(3)]
    public float waitingForNextSpawn = 10;
    public float theCountdown = 10;

    // the range of X
    [Header("X Spawn Range")]
    public float xMin;
    public float xMax;

    // the range of y
    [Header("Y Spawn Range")]
    public float yMin;
    public float yMax;

    public Transform[] Spawners;
    public int random;

    public int EnemyCount;

    //int LevelCount;

    int CurrentLevel;

    [SerializeField] Level[] Levels;
    [SerializeField] float Delay;

    bool NextSpawn;

    public int Current1Enemy;
    public int Current2Enemy;
    public int Current3Enemy;
    public int Current4Enemy;

    public int CurrentWave;

    bool isSpawn;

    public GameObject CurMap;
    void Start()
    {
        CurMap = Instantiate<GameObject>(Levels[CurrentLevel].LevelPrefab, Vector3.zero, Quaternion.identity);

        Spawn();
    }
    void Update()
    {
        //if (�nput.getkeydown(keycode.space))
        //{
        //    spawngoodies();
        //}
        //if(enemycount == 0)
        //{
        //    gameobject.find("levelmanager").getcomponent<levelmanager>().nextlevel();
        //    levelcount++;
        //    enemycount = random.range(levelcount, 2 * levelcount);
        //}

        //if(EnemyCount == 0 && isSpawn)
        //{
        //    isSpawn = false;
        //    if (NextSpawn)
        //    {
        //        NextSpawn = false;
        //        CurrentWave++;
        //        ResetCurrentEnemy();
        //        /////////
        //        //if (CurrentWave+1 <= Levels[CurrentLevel].waves.Length)
        //        //{
        //        //    CurrentWave++;
        //        //    ResetCurrentEnemy();
        //        //}
        //        //else
        //        //{
        //        //}                             
        //    }
        //    else
        //    {
        //        CurrentLevel++;
        //        ResetWave();
        //    }
        //    Invoke("Spawn", 2 * Delay);
        //}





        if (EnemyCount == 0 && isSpawn)
        {
            isSpawn = false;

            Debug.Log("Next" + NextSpawn);
            if (NextSpawn == false)
            {
                NextSpawn = false;
                CurrentWave++;
                ResetCurrentEnemy();
            }
            else
            {
                if (CurrentWave + 1 < Levels[CurrentLevel].waves.Length)
                {
                    Debug.Log(CurrentWave + " + 1 <" + Levels[CurrentLevel].waves.Length);
                    CurrentWave++;
                    ResetCurrentEnemy();
                }
                else
                {
                    //Destroy(CurMap);
                    //CurrentLevel++;
                    //GameObject.Find("Player").transform.position = Vector3.zero;
                    //Debug.Log("Current Level: "+CurrentLevel+ " " + Levels[CurrentLevel]);
                    //CurMap = Instantiate<GameObject>(Levels[CurrentLevel].LevelPrefab, Vector3.zero, Quaternion.identity);
                    //ResetWave();
                    SceneManager.LoadScene(3);
                }
            }
            Invoke("Spawn", 2 * Delay);
        }
    }
    void SpawnGoodies()
    {
        // Defines the min and max ranges for x and y
        //  Vector2 pos = new Vector2(Random.Range(xMin, xMax), Random.Range(yMin, yMax));
        random = Random.Range(0, Spawners.Length);
        // Creates the random object at the random 2D position.
        EnemyCount++;
        Instantiate(goods, Spawners[random].position, this.transform.rotation);


    }

    void Spawn()
    {
        NextSpawn = false;
        

        Debug.Log("Level" + CurrentLevel + " , Wave " + CurrentWave);
        Wave CurCurrentWave = Levels[CurrentLevel].waves[CurrentWave];

        if (Current1Enemy < CurCurrentWave.Spawner1Enemies.Length)
        {
            EnemyCount++;
            Debug.Log("1");
            Instantiate(CurCurrentWave.Spawner1Enemies[Current1Enemy], Spawners[0].position, transform.rotation);

            Current1Enemy++;         
            if (Current1Enemy <= CurCurrentWave.Spawner1Enemies.Length + 1)
            {
                Debug.Log(Current1Enemy+ " < " +CurCurrentWave.Spawner1Enemies.Length);
                NextSpawn = true;
            }
        }
        if (Current2Enemy < CurCurrentWave.Spawner2Enemies.Length)
        {
            EnemyCount++;
            Debug.Log("2");
            Instantiate(CurCurrentWave.Spawner2Enemies[Current2Enemy], Spawners[1].position, transform.rotation);

            Current2Enemy++;
            if (Current2Enemy <= CurCurrentWave.Spawner2Enemies.Length + 1)
            {
                Debug.Log(Current2Enemy + " < " + CurCurrentWave.Spawner2Enemies.Length);
                NextSpawn = true;
            }
        }
        if (Current3Enemy < CurCurrentWave.Spawner3Enemies.Length)
        {
            EnemyCount++;
            Debug.Log("3");
            Instantiate(CurCurrentWave.Spawner3Enemies[Current3Enemy], Spawners[2].position, transform.rotation);

            Current3Enemy++;
            if (Current3Enemy <= CurCurrentWave.Spawner3Enemies.Length + 1)
            {
                Debug.Log(Current3Enemy + " < " + CurCurrentWave.Spawner3Enemies.Length);
                NextSpawn = true;
            }
        }
        if (Current4Enemy < CurCurrentWave.Spawner4Enemies.Length)
        {
            EnemyCount++;
            Debug.Log("4");
            Instantiate(CurCurrentWave.Spawner4Enemies[Current4Enemy], Spawners[3].position, transform.rotation);

            Current4Enemy++;
            if (Current4Enemy <= CurCurrentWave.Spawner4Enemies.Length+1)
            {
                Debug.Log(Current4Enemy + " < " + CurCurrentWave.Spawner4Enemies.Length);
                NextSpawn = true;
            }
        }
        isSpawn = true;
    }
    private void OnDestroy()
    {
        
    }
    void ResetWave()
    {
        CurrentWave = 0;
    }
    void ResetCurrentEnemy()
    {
        Current1Enemy = 0;
        Current2Enemy = 0;
        Current3Enemy = 0;
        Current4Enemy = 0;
    }

    public void ChangeEnemyCount()
    {
        EnemyCount--;
    }
}
