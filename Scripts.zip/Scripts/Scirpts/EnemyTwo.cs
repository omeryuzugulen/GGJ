using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyTwo : MonoBehaviour
{
    public Transform target;
    public Vector3 LastTarget;
    Vector3 LastPos;

    public float speed = 6f;
    public float Attackspeed = 6f;
    private float minDistance = 1f;
    private float range;

    public bool bullet;
    public GameObject Bullet;
    public Transform BulletTransform;

    Vector2 lookdir;
    Vector2 playerpos;
    Rigidbody2D rb;

    [SerializeField] GameObject Particle;

   

    [SerializeField] GameObject Trail;

    public enum State {
        gotoplayer,
        gotoplayershot
    }
    public State CurnState;
    public float gotoplayghoststartentertime;

    private void Start()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    void Update()
    {
        target = GameObject.Find("Player").transform;
        //range = Vector2.Distance(transform.position, target.position);

        switch (CurnState)
        {
            case State.gotoplayer:
                Trail.SetActive(false);
                transform.position = Vector2.MoveTowards(transform.position, target.position, speed * Time.deltaTime);
                
                break;
            case State.gotoplayershot:
                this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
                if (Time.time - gotoplayghoststartentertime > 1)
                {
                
                    if (Time.time - gotoplayghoststartentertime > 2)
                    {
                        if (!bullet)
                        {
                            bullet = true;
                            Instantiate(Bullet, LastPos, transform.rotation);
                            CurnState = State.gotoplayer;
                        }
                    }
                }
                break;
            default:
                break;
        }
    }
    private void FixedUpdate()
    {
        lookdir = playerpos - rb.position;
        float angle = Mathf.Atan2(lookdir.y, lookdir.x) * Mathf.Rad2Deg;
        rb.rotation = angle;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.TryGetComponent<PlayerCricleTwo>(out var playerCricleTwo))
        {
            CurnState = State.gotoplayershot;
            gotoplayghoststartentertime = Time.time;
            LastPos = target.transform.position;
        }
        if(collision.gameObject.TryGetComponent<BulletScript>(out var bulletScript))
        {            
            Instantiate<GameObject>(Particle, transform.position, Quaternion.identity);
            GameObject.Find("Main Camera").GetComponent<Animator>().SetTrigger("ShakeBigger");
            Destroy(gameObject);
        }
        if (collision.gameObject.TryGetComponent<Enemy>(out var enemy))
        {
            this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, this.transform.position.z);
        }
    }
    private void OnDestroy()
    {
        FindObjectOfType<EnemySpawn>().ChangeEnemyCount();
        Debug.Log("Oldum");
    }
}
